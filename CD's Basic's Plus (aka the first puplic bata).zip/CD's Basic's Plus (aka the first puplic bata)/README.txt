This is the template texture pack!
You can check the "core" pack for more information about what assets you can replace.
Editing "core" won't do anything, as it is not a texture pack, and any changes will simply be ignored.
The replacement system is relatively complicated, and I plan on making a tutorial covering that soon!