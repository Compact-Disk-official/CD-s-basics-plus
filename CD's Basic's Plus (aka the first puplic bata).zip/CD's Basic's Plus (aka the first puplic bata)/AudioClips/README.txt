No audio dumping is currently available.
These sounds are not played using a SoundObject, meaning they have no subtitle.
Below is a list of valid AudioClips and what they are attached to.
GrappleLoop (MotorAudio,MotorAudio,MotorAudio,MotorAudio,MotorAudio)
cafe_ambience (CafeteriaRoomFunction)
Static (StaticImage,StaticImage,StaticImage)
Jon_InfoMap (Jon_InfoMap,Jon_InfoMap)
Vent_Travel (VentController)
WindLoop (CampHubRoomFunction)
PlaygroundAmbience (FieldTripEntranceRoomFunction,PlaygroundRoomFunction)
ComputerHum (MyComputer)
BAL_Wow (IntroSounds)
BAL_ThanksForPlaying (Menu)
ErrorScreen (SaveError)
BAL_NameEntry (NameList)
