No audio dumping is currently available.
Below is a list of valid SoundObjects that you can replace(on the left)
And their associated subtitle, subtitle key, and AudioClip name.
AlarmClockBell->*Alarm clock RIIIING!*(SFX_Items_ClockBell) | AlarmClockBell
ClockWind->*Winding*(Sfx_ClockWind) | ClockWind
BsodaSpray->(Nothing) | BsodaSpray
ChalkEraser->Sfx_ChalkEraser(Sfx_ChalkEraser) | ChalkEraser
GrappleLaunch->(Nothing) | GrappleLaunch
GrappleClang->(Nothing) | GrappleClang
BAL_Break->*SNAP*(Sfx_Baldi_Break) | BAL_Break
NoSquee->*WHOOSH*(Sfx_Items_NoSquee) | NoSquee
CoinDrop->Sfx_CoinDrop(Sfx_CoinDrop) | CoinDrop
ChipCrunch->*CRUNCH*(Sfx_Misc_ChipCrunch) | ChipCrunch
Scissors->Sfx_Scissors(Sfx_Scissors) | Scissors
Teleport->*BREOW!*(Sfx_Item_Teleport) | Teleport
Slap->*Slap!*(Sfx_Slap) | Slap
ErrorMaybe->Not here.(Sfx_ErrorMaybe) | ErrorMaybe
Nana_Sput->*splat*(Sfx_Nana_Sput) | Nana_Sput
Nana_Loop->*SLIPPING SOUNDS*(Sfx_Nana_Loop) | Nana_Loop
Nana_Slip->*WOOOO*(Sfx_Nana_Slip) | Nana_Slip
PriWhistle->*Whistling*(Sfx_Items_PriWhistle) | PriWhistle
Doors_StandardOpen->*Door opens*(Sfx_Doors_StandardOpen) | Doors_StandardOpen
AlarmClockTick->*Ticking*(SFX_Items_ClockTick) | AlarmClockTick
1PR_Motor->*Motor running*(Sfx_1PR_Motor) | 1PR_Motor
Activity_Correct->*Correct chime*(Sfx_Activity_Correct) | Activity_Correct
Activity_Incorrect->*Incorrect buzz*(Sfx_Activity_Incorrect) | Activity_Incorrect
AppleCrunch->*CRONCH*(Sfx_AppleCrunch) | AppleCrunch
AutoDoor_Close->*Auto door closes*(Sfx_AutoDoor_Close) | Elv_Close_Real
AutoDoor_Open->*Auto door opens*(Sfx_AutoDoor_Open) | Elv_Open_Real
BAL_Slap->*SLAP*(Sfx_Baldi_Slap) | BAL_Slap
Bang->*Bang!*(Sfx_Bang) | Bang
Ben_Blowing->Sfx_Ben_Blowing(Sfx_Ben_Blowing) | Ben_Blowing
Ben_Gum_Whoosh->*WHOOSH*(Sfx_Ben_Gum_Whoosh) | Ben_Gum_Whoosh
Ben_Splat->*SPLAT!*(Sfx_Ben_Splat) | Ben_Splat
Boink->Sfx_Boink(Sfx_Boink) | Boink
BusLoop->Sfx_BusLoop(Sfx_BusLoop) | BusLoop
CFT_Intro->*STATIC*(Sfx_Crafters_Intro) | CFT_Intro
CFT_Loop->*STATIC*(Sfx_Crafters_Loop) | CFT_Loop
CampfireLand->Sfx_CampfireLand(Sfx_CampfireLand) | CampfireLand
CampfireToss->Sfx_CampfireToss(Sfx_CampfireToss) | CampfireToss
CartoonEating->Sfx_CartoonEating(Sfx_CartoonEating) | CartoonEating
CartoonKnock_Trimmed->*STOMP*(Sfx_CartoonKnock_Trimmed) | CartoonKnock_Trimmed
CashBell->Sfx_CashBell(Sfx_CashBell) | CashBell
Cmlo_Blowing->*WIND BLOWING*(Vfx_Cmlo_Blowing) | Cmlo_Blowing
ComputerHum->Sfx_ComputerHum(Sfx_ComputerHum) | ComputerHum
CoverLift->Sfx_CoverLift(Sfx_CoverLift) | CoverLift
Doors_Knock_Delay->*Knock Knock Knock*(Sfx_Doors_Knock) | Doors_Knock_Delay
Doors_Locker->*SLAM!*(Sfx_Doors_Locker) | Doors_Locker
Doors_LockerOpen->Sfx_Doors_LockerOpen(Sfx_Doors_LockerOpen) | Doors_LockerOpen
Doors_StandardLock->*Click!*(Sfx_Doors_StandardLock) | Doors_StandardLock
Doors_StandardLocked->*Rattling*(Sfx_Doors_StandardLocked) | Doors_StandardLocked
Doors_StandardShut->*SLAM!*(Sfx_Doors_StandardShut) | Doors_StandardShut
Doors_StandardUnlock->*Unclick!*(Sfx_Doors_StandardUnlock) | Doors_StandardUnlock
Doors_Swinging->*Swinging door opens*(Sfx_Doors_Swinging) | Doors_Swinging
DrR_Hammer->*Bang!*(Sfx_Bang) | DrR_Hammer
Elv_Buzz->*BUZZ*(Sfx_Elv_Buzz) | Elv_Buzz
Elv_Close_Real->*Elevator closes*(Sfx_Elv_Close) | Elv_Close_Real
Elv_Gate->*SLAM!*(Sfx_Elv_Gate) | Gate
Elv_Open_Real->*Elevator opens(Sfx_Elv_Open) | Elv_Open_Real
Explosion->Sfx_Explosion(Sfx_Explosion) | Explosion
FireFueled->Sfx_FireFueled(Sfx_FireFueled) | FireFueled
Fuse->Sfx_Fuse(Sfx_Fuse) | Fuse
Gen_Pop->*POP!*(Sfx_Effects_Pop) | Gen_Pop
GlassBreak->*Crash!*(Sfx_GlassBreak) | GlassBreak
ItemPickup->Sfx_ItemPickup(Sfx_ItemPickup) | ItemPickup
LAt_Activating->Sfx_LAt_Activating(Sfx_LAt_Activating) | LAt_Activating
LAt_BlindLoop->Sfx_LAt_BlindLoop(Sfx_LAt_BlindLoop) | LAt_BlindLoop
LAt_BlindStart->*Humming noise*(Sfx_LAt_BlindStart) | LAt_BlindStart
LAt_Loop->*Humming noise*(Sfx_LAt_Loop) | LAt_Loop
LAt_Sighted->Sfx_LAt_Sighted(Sfx_LAt_Sighted) | LAt_Sighted
LockDoorStop->*THUD*(Sfx_Doors_LockStop) | LockDoorStop
LockdownDoor_Move->*Door motor running*(Sfx_LockdownDoor) | LockdownDoor
NoteRespawn->A notebook respawned!(Sfx_NoteRespawn) | NoteRespawn
NotebookCollect->Sfx_NotebookCollect(Sfx_NotebookCollect) | NotebookCollect
PlateDrop->Sfx_PlateDrop(Sfx_PlateDrop) | PlateDrop
PlateLift->Sfx_PlateLift(Sfx_PlateLift) | PlateLift
Sfx_Button_Press->Sfx_Button_Press(Sfx_Button_Press) | Sfx_Button_Press
Sfx_Button_Unpress->Sfx_Button_Unpress(Sfx_Button_Unpress) | Sfx_Button_Unpress
ShrinkMachine_Door->*WHIRR*(Sfx_ShrinkMachine_Door) | ShrinkMachine_Door
SwingDoorLock->Sfx_SwingDoorLock(Sfx_SwingDoorLock) | SwingDoorLock
TapeInsert->Sfx_TapeInsert(Sfx_TapeInsert) | TapeInsert
TimeLimitBell->*RIIIING!*(Sfx_TimeLimitBell) | TimeLimitBell
TimeLimitTicking->*tick* *tock* *tick* *tock* *tick* *tock*(Sfx_TimeLimitTicking) | TimeLimitTicking
VentHit_0->*Bang!*(Sfx_Bang) | VentHit_0
VentHit_1->*Bang!*(Sfx_Bang) | VentHit_1
VentHit_2->*Bang!*(Sfx_Bang) | VentHit_2
VentHit_3->*Bang!*(Sfx_Bang) | VentHit_3
Vent_Vacuum->*Woosh!*(Sfx_Woosh) | Vent_Vacuum
WaterSlurp->*Slurp*(Sfx_Slurp) | WaterSlurp
WeirdError->Sfx_WeirdError(Sfx_WeirdError) | WeirdError
YTPPickup_0->Sfx_YTPPickup_0(Sfx_YTPPickup_0) | YTPPickup_0
YTPPickup_1->Sfx_YTPPickup_1(Sfx_YTPPickup_1) | YTPPickup_1
YTPPickup_2->Sfx_YTPPickup_2(Sfx_YTPPickup_2) | YTPPickup_2
ConveyorBeltLoop->*Conveyor belt running*(Sfx_ConveyorBeltLoop) | ConveyorBeltLoop
Coughing->Sfx_Coughing(Sfx_Coughing) | Coughing
Fire->*Fire crackling*(Sfx_Fire) | Fire
ambience1->Sfx_ambience1(Sfx_ambience1) | ambience1
ambience2->Sfx_ambience2(Sfx_ambience2) | ambience2
ambience3->Sfx_ambience3(Sfx_ambience3) | ambience3
ambience4->Sfx_ambience4(Sfx_ambience4) | ambience4
ambience5->Sfx_ambience5(Sfx_ambience5) | ambience5
ambience6->Sfx_ambience6(Sfx_ambience6) | ambience6
AntiHearing->*Annoying noise*(SFX_Items_AntiHearing) | AntiHearing
Mus_Party->*Wholesome party music*(Mfx_Party) | mus_party
mus_Playtime->*Music*(Mfx_mus_Playtime) | mus_Playtime
MusicTest->8(Vfx_Test_8) | Creepy Old Computer
BAL_AllNotebooks_4->Congratulations! You found all(Vfx_BAL_AllNotebooks_1) | BAL_AllNotebooks_4
BAL_AllNotebooks_7->Congratulations! You found all(Vfx_BAL_AllNotebooks_1) | BAL_AllNotebooks_7
BAL_AllNotebooks_9->Congratulations! You found all(Vfx_BAL_AllNotebooks_1) | BAL_AllNotebooks_9
BAL_Apple->An Apple? For me? Thanks!(Vfx_BAL_Apple) | BAL_Apple
BAL_Count1->1!(Vfx_1!) | BAL_Count1
BAL_Count10->10!(Vfx_10!) | BAL_Count10
BAL_Count2->2!(Vfx_2!) | BAL_Count2
BAL_Count3->3!(Vfx_3!) | BAL_Count3
BAL_Count4->4!(Vfx_4!) | BAL_Count4
BAL_Count5->5!(Vfx_5!) | BAL_Count5
BAL_Count6->6!(Vfx_6!) | BAL_Count6
BAL_Count7->7!(Vfx_7!) | BAL_Count7
BAL_Count8->8!(Vfx_8!) | BAL_Count8
BAL_Count9->9!(Vfx_9!) | BAL_Count9
BAL_Event_Flood->Looks like the leak is leaking again.(Vfx_BAL_Event_Flood_1) | BAL_Event_Flood
BAL_Event_Fog->Uh oh. Looks like my fog machine is malfunctioning again.(Vfx_BAL_Event_Fog_1) | BAL_Event_Fog
BAL_Event_Gravity->Woah! Gravity is going crazy!(Vfx_BAL_Event_Gravity_1) | BAL_Event_Gravity
BAL_Event_MysteryRoom->Hey! A mystery room has appeared.(Vfx_BAL_Event_MysteryRoom_1) | BAL_Event_MysteryRoom
BAL_Event_Party->Party at the Principal's office! Everyone's invited!(Vfx_BAL_Event_Party_1) | BAL_Event_Party
BAL_Event_Ruler->AAAAAAAAAAAAAAAAAAAAAAAAA(Vfx_BAL_Event_Ruler) | BAL_Event_Ruler
BAL_Event_TestProcedure->Attention! Attention everyone! Test procedure is imminent!(Vfx_BAL_Event_TestProcedure_1) | BAL_Event_TestProcedure
BAL_GameOver->Vfx_BAL_GameOver(Vfx_BAL_GameOver) | BAL_GameOver
BAL_HideSeek->Oh, hi! Let's play hide and seek!(Vfx_BAL_HideSeek) | BAL_HideSeek
BAL_HighScore->Vfx_BAL_HighScore(Vfx_BAL_HighScore) | BAL_HighScore
BAL_IntroKL2->You're good! Let's keep playing!(Vfx_Baldi_KSL2) | BAL_IntroKL2
BAL_IntroKL3->What fun! Goo-(Vfx_Baldi_KSL3) | BAL_IntroKL3
BAL_Intro_Camping->Let's go camping!(Vfx_BAL_Intro_Camping) | BAL_Intro_Camping
BAL_LetsGo->Vfx_BAL_LetsGo(Vfx_BAL_LetsGo) | BAL_LetsGo
BAL_Math_0->0(Vfx_0) | BAL_Math_0
BAL_Math_1->1(Vfx_1) | BAL_Math_1
BAL_Math_2->2(Vfx_2) | BAL_Math_2
BAL_Math_3->3(Vfx_3) | BAL_Math_3
BAL_Math_4->4(Vfx_4) | BAL_Math_4
BAL_Math_5->5(Vfx_5) | BAL_Math_5
BAL_Math_6->6(Vfx_6) | BAL_Math_6
BAL_Math_7->7(Vfx_7) | BAL_Math_7
BAL_Math_8->8(Vfx_8) | BAL_Math_8
BAL_Math_9->9(Vfx_9) | BAL_Math_9
BAL_NoPasss->Wait! You don't have a bus pass.(Vfx_BAL_NoPass_0) | BAL_NoPasss
BAL_Ohh->Ohhhh...(Vfx_BAL_Ohh) | BAL_Ohh
BAL_Praise1->Aha! You got it!(Vfx_BAL_Praise1) | BAL_Praise1
BAL_Praise2->Great job! That's right!(Vfx_BAL_Praise2) | BAL_Praise2
BAL_Praise3->Good one!(Vfx_BAL_Praise3) | BAL_Praise3
BAL_Praise4->You're doing fantastic!(Vfx_BAL_Praise4) | BAL_Praise4
BAL_Praise5->I can't believe it! You're incredible!(Vfx_BAL_Praise5) | BAL_Praise5
BAL_Praise6->Woah, I think you might be smarter than me!(Vfx_BAL_Praise6) | BAL_Praise6
BAL_ReadyOrNot->Ready or not, here I come!(Vfx_BAL_ReadyOrNot) | BAL_ReadyOrNot
BAL_TimeOut->Class dismissed! School is no longer in session!(Vfx_BAL_TimeOut_1) | BAL_TimeOut
BAL_Wow->WOW!(Vfx_BAL_Wow) | BAL_Wow
BAL_YouWon->Vfx_BAL_YouWon(Vfx_BAL_YouWon) | BAL_YouWon
BAL_Yum->Yum!(Vfx_BAL_Yum) | BAL_Yum
BaldiSings1->You beat my game!(Vfx_BaldiSings1) | BaldiSings1
BaldiSings2->You learned a lot!(Vfx_BaldiSings2) | BaldiSings2
BaldiSings3->It's good you came,(Vfx_BaldiSings3) | BaldiSings3
BaldiSings4->'cuz you were taught!(Vfx_BaldiSings4) | BaldiSings4
BaldiSings5->Now that you know(Vfx_BaldiSings5) | BaldiSings5
BaldiSings6->to use your brain!(Vfx_BaldiSings6) | BaldiSings6
BaldiSings7->I'll let you go(Vfx_BaldiSings7) | BaldiSings7
BaldiSings8->'til you come again!(Vfx_BaldiSings8) | BaldiSings8
Lose_Buzz->BUZZ(Sfx_Lose_Buzz) | Lose_Buzz
Lose_Corruption->BUZZ(Sfx_Lose_Buzz) | Lose_Corruption
Lose_Corruption2->BUZZ(Sfx_Lose_Buzz) | Lose_Corruption2
Lose_Creepy->BUZZ(Sfx_Lose_Buzz) | Lose_Creepy
Lose_GlassBoom->BUZZ(Sfx_Lose_Buzz) | Lose_GlassBoom
Lose_NO->BUZZ(Sfx_Lose_Buzz) | Lose_NO
Lose_SteamExplode->BUZZ(Sfx_Lose_Buzz) | Lose_SteamExplode
Lose_What->BUZZ(Sfx_Lose_Buzz) | Lose_What
run->run(Vfx_run) | run
BAL_CampingIntro->Welcome to the campsite!(Vfx_Camp_CampingIntro_1) | BAL_CampingIntro
Ben_Anyone->Does anyone wanna see somethin' cool?(Vfx_Ben_Anyone) | Ben_Anyone
Ben_BeSent->I'll be sent to the guy of the Thing, smacking my head 'n' causing a ring!(Vfx_Ben_BeSent) | Ben_BeSent
Ben_FeastEyes->Feast your eyes while I feast on mah gum!(Vfx_Ben_FeastEyes) | Ben_FeastEyes
Ben_Grownups->Psst! Don't let the grownups spot this.(Vfx_Ben_Grownups) | Ben_Grownups
Ben_HeyYou->Hey you, watch this!(Vfx_Ben_HeyYou) | Ben_HeyYou
Ben_HippityHey->Hippity hey, look at the time; I need to fetch some more rhyme.(Vfx_Ben_HippityHey) | Ben_HippityHey
Ben_NeatTrick->Say, who's lookin' to see a neat trick?(Vfx_Ben_NeatTrick) | Ben_NeatTrick
Ben_NeverHere->Welp, I was never here!(Vfx_Ben_NeverHere) | Ben_NeverHere
Ben_Nope->Uh... nope.(Vfx_Ben_Nope) | Ben_Nope
Ben_Prepare->Prepare yourself for something awesome!(Vfx_Ben_Prepare) | Ben_Prepare
Ben_Skip_Away->Skip away, skip away, it'll go away.(Vfx_Beans_Skip_Away) | Ben_Skip_SkipAway
Ben_Skip_Buckle->One, two, buckle my shoe. Three, four, I've got gum for you!(Vfx_Beans_Skip_Buckle) | Ben_Skip_Buckle
Ben_Skip_Chant->Hooka, a-chew, I'mma chewin' mah gum.(Vfx_Ben_Skip_Chant1) | Ben_Skip_Chant
Ben_Skip_Pain->I skip all day, I say-I say, I skip to push the pain away!(Vfx_Beans_Skip_Pain) | Ben_Skip_Pain
Ben_Sorry->They're gonna be so mad at me, I'm so sorry!(Vfx_Ben_Sorry) | Ben_Sorry
Ben_Spit->*SPITS GUM*(Vfx_Ben_Spit) | Ben_Spit
Ben_Spit_CantLook->I can't look!(Vfx_Ben_Spit_CantLook) | Ben_Spit_CantLook
Ben_Spit_Casserole->Aw, casserole.(Vfx_Ben_Spit_Casserole) | Ben_Spit_Casserole
Ben_Spit_HeadsUp->Heads up!(Vfx_Ben_Spit_HeadsUp) | Ben_Spit_HeadsUp
Ben_Spit_HeldBack->Huh, so maybe that's why they held me back.(Vfx_Ben_Spit_HeldBack) | Ben_Spit_HeldBack
Ben_Spit_OhNo->Oh no!(Vfx_Ben_Spit_OhNo) | Ben_Spit_OhNo
Ben_Spit_Scream->Gum on the loose!(Vfx_Ben_GumLoose) | Ben_Spit_Scream
Ben_Spit_SorryAdvance->Sorry in advance!(Vfx_Ben_Spit_SorryAdvance) | Ben_Spit_SorryAdvance
Ben_Spit_WatchOut->Watch out!(Vfx_Ben_Spit_WatchOut) | Ben_Spit_WatchOut
Ben_TimeBounce->Time to bounce, time to flee, before they throw the book at me!(Vfx_Ben_TimeBounce) | Ben_TimeBounce
Ben_WatchPro->Watch the pro go to work!(Vfx_Ben_WatchPro) | Ben_WatchPro
BUL_Bored->I'm bored...(Vfx_Bully_Bored) | BUL_Bored
BUL_Donation->Thanks for the generous donation!..(Vfx_Bully_Donation) | BUL_Donation
BUL_GiveGreat->Give me something great...(Vfx_Bully_GiveGreat) | BUL_GiveGreat
BUL_NoItems->What?! No Items? No items, no pass...(Vfx_Bully_NoItems) | BUL_NoItems
BUL_TakeCandy->I'm gonna take your candy...(Vfx_Bully_TakeCandy) | BUL_TakeCandy
BUL_TakeThat->I'll take that! It's mine now...(Vfx_Bully_TakeThat) | BUL_TakeThat
Chk_Laugh->*ANNOYING LAUGHTER*(Sfx_Chalk_Laugh) | Chk_Laugh
Chk_Spawn->*WARBLING*(Sfx_Chalk_Spawn) | Chk_Spawn
DrR_AllDone->All done!(Vfx_DrR_AllDone) | DrR_AllDone
DrR_Angry_Random_0->I just need to finish your test!(Vfx_DrR_Angry_Random_0) | DrR_Angry_Random_0
DrR_Angry_Random_1->Get back here!(Vfx_DrR_Angry_Random_1) | DrR_Angry_Random_1
DrR_Angry_Random_2->This won't hurt a bit!(Vfx_DrR_Angry_Random_2) | DrR_Angry_Random_2
DrR_Angry_Random_3->Don't be afraid of my hammer!(Vfx_DrR_Angry_Random_3) | DrR_Angry_Random_3
DrR_Angry_Random_4->Where'd you goOOo?(Vfx_DrR_Angry_Random_4) | DrR_Angry_Random_4
DrR_Angry_Random_5->HMMmmm...(Vfx_DrR_Angry_Random_5) | DrR_Angry_Random_5
DrR_Angry_Random_6->This will look bad on my résumé!(Vfx_DrR_Angry_Random_6) | DrR_Angry_Random_6
DrR_Angry_Random_7->You're gonna make me CRY!(Vfx_DrR_Angry_Random_7) | DrR_Angry_Random_7
DrR_EverythingGood->Everything looks good!(Vfx_DrR_EverythingGood) | DrR_EverythingGood
DrR_Fast->...FAST!(Vfx_DrR_Fast) | DrR_Fast
DrR_Faster->Do it FASTER next time!(Vfx_DrR_Faster) | DrR_Faster
DrR_FirstTry->Woah! First try!(Vfx_DrR_FirstTry) | DrR_FirstTry
DrR_GoodJob->Good job! That was fast!(Vfx_DrR_GoodJob) | DrR_GoodJob
DrR_Happy_Random_0->Does anyone need a checkup?(Vfx_DrR_Happy_Random_0) | DrR_Happy_Random_0
DrR_Happy_Random_1->I'll test your reflexes!(Vfx_DrR_Happy_Random_1) | DrR_Happy_Random_1
DrR_Happy_Random_2->Who wants their reflexes checked?(Vfx_DrR_Happy_Random_2) | DrR_Happy_Random_2
DrR_Happy_Random_3->Anyone feeling down? Come and see me!(Vfx_DrR_Happy_Random_3) | DrR_Happy_Random_3
DrR_Happy_Random_4->My test will heals what ails ya!(Vfx_DrR_Happy_Random_4) | DrR_Happy_Random_4
DrR_HitCircle->Hit the circle!(Vfx_DrR_HitCircle) | DrR_HitCircle
DrR_Indisputable->The test results are indisputable!(Vfx_DrR_Indisputable) | DrR_Indisputable
DrR_NotSoBad->See? That wasn't so bad!(Vfx_DrR_NotSoBad) | DrR_NotSoBad
DrR_SessionNotOver->What?! Your session's not over yet!(Vfx_DrR_SessionNotOver) | DrR_SessionNotOver
DrR_Think_End->...iiink(Vfx_DrR_Think_End) | DrR_Think_End
DrR_Think_Intro->Thiii...(Vfx_DrR_Think_Intro) | DrR_Think_Intro
DrR_Think_Loop->...iiiiiiiiiii...(Vfx_DrR_Think_Loop) | DrR_Think_Loop
DrR_TooSlow->Toooo slow!(Vfx_DrR_TooSlow) | DrR_TooSlow
DrR_TryAgain->Try again!(Vfx_DrR_TryAgain) | DrR_TryAgain
DrR_UhOh->Uh oh!(Vfx_DrR_UhOh) | DrR_UhOh
DrR_Whoops->Whoops!(Vfx_DrR_Whoops) | DrR_Whoops
DrR_Wrong->That's the wrong one!(Vfx_DrR_Wrong) | DrR_Wrong
DrR_YouHealthy->The test results conclude that you are healthy!(Vfx_DrR_YouHealthy) | DrR_YouHealthy
1PR_AmComing->I AM COMING READY OR NOR HERE I COME(Vfx_Prize_AmComing) | 1PR_AmComing
1PR_AmLooking->I AM LOOKING FOR YOU(Vfx_Prize_AmLooking) | 1PR_AmLooking
1PR_BeenProgrammed->I HAVE BEEN PROGRAMMED TO DESIRE YOUR IMAGE(Vfx_Prize_BeenProgrammed) | 1PR_BeenProgrammed
1PR_HaveLost->I HAVE LOST YOU - I DON'T LIKE THAT(Vfx_Prize_HaveLost) | 1PR_HaveLost
1PR_IHug->I HUG PEOPLE FOR ALL ETERNITY(Vfx_Prize_IHug) | 1PR_IHug
1PR_ISeeYou->I SEE YOU - FRIEND(Vfx_Prize_ISeeYou) | 1PR_ISeeYou
1PR_Marry->WILL YOU MARRY ME(Vfx_Prize_Marry) | 1PR_Marry
1PR_OhNo->OH - no(Vfx_Prize_OhNo) | 1PR_OhNo
GS_GottaSweep->Gotta, sweep sweep sweep!(Vfx_Sweep_GottaSweep) | GS_GottaSweep
GS_Intro->Looks like it's sweepin' time!(Vfx_Sweep_Intro) | GS_Intro
Jon_BusPass->Wow, thanks! I love field trips!(Vfx_Jon_BusPass) | Jon_BusPass
Jon_Buy1->I love those!(Vfx_Jon_Buy1) | Jon_Buy1
Jon_Buy2->That could come in handy!!(Vfx_Jon_Buy2) | Jon_Buy2
Jon_Buy3->Totally worth the price!(Vfx_Jon_Buy3) | Jon_Buy3
Jon_Buy4->Thank you! Now I might not starve!(Vfx_Jon_Buy4) | Jon_Buy4
Jon_Buy5->Thank you! My parents would have been so proud that I made a sale.(Vfx_Jon_Buy5) | Jon_Buy5
Jon_Buy6->Thanks, I hated that item anyways!(Vfx_Jon_Buy6) | Jon_Buy6
Jon_DidntWant->I didn't really want food today anyways...(Vfx_Jon_DidntWant) | Jon_DidntWant
Jon_Expel1->Alright, I'll take care of it.(Vfx_Jon_Expel1) | Jon_Expel1
Jon_Expel2->Okay, I'll let them know.(Vfx_Jon_Expel2) | Jon_Expel2
Jon_Expel3->You are a JERK!(Vfx_Jon_Expel3) | Jon_Expel3
Jon_FaveCustomer->You're my favorite customer. See ya!(Vfx_Jon_FaveCustomer) | Jon_FaveCustomer
Jon_Help->I'll take care of it.(Vfx_Jon_Help) | Jon_Help
Jon_Hi->Hi, I'm Johnny!(Vfx_Jon_Hi) | Jon_Hi
Jon_InfoExpel->You can expel someone for the rest of your game!(Vfx_Jon_InfoExpel) | Jon_InfoExpel
Jon_InfoMapShort->This will fill out your map.(Vfx_Jon_InfoMapShort) | Jon_InfoMapShort
Jon_MapFilled->Consider your map filled!(Vfx_Jon_MapFilled) | Jon_MapFilled
Jon_MapFilled2->No way you'll get lost now!(Vfx_Jon_MapFilled2) | Jon_MapFilled2
Jon_SayHi->Say hi to Baldi for me!(Vfx_Jon_SayHi) | Jon_SayHi
Jon_SeeLater->See ya later. I'll still be here!(Vfx_Jon_SeeLater) | Jon_SeeLater
Jon_ThankYou->Thank you for shopping!(Vfx_Jon_ThankYou) | Jon_ThankYou
Jon_ThanksNot->Thanks for nothing!(Vfx_Jon_ThanksNot) | Jon_ThanksNot
Jon_ThatWasFun->Wow, that was so much fun! I brought some items back for ya.(Vfx_Jon_ThatWasFun) | Jon_ThatWasFun
Jon_TooMuch1->Lookin' like you ain't learnin'!(Vfx_Jon_TooMuch1) | Jon_TooMuch1
Jon_TooMuch2->Try again when you have more You Thought Points.(Vfx_Jon_TooMuch2) | Jon_TooMuch2
Jon_TooMuch3->You can't afford that!(Vfx_Jon_TooMuch3) | Jon_TooMuch3
Jon_Welcome->Welcome to my store!(Vfx_Jon_Welcome) | Jon_Welcome
ComputerCount_0->0(Vfx_0) | ComputerCount_0
ComputerCount_1->1(Vfx_1) | ComputerCount_1
ComputerCount_2->2(Vfx_2) | ComputerCount_2
ComputerCount_3->3(Vfx_3) | ComputerCount_3
ComputerCount_4->4(Vfx_4) | ComputerCount_4
ComputerCount_5->5(Vfx_5) | ComputerCount_5
ComputerCount_6->6(Vfx_6) | ComputerCount_6
ComputerCount_7->7(Vfx_7) | ComputerCount_7
ComputerCount_8->8(Vfx_8) | ComputerCount_8
ComputerCount_9->9(Vfx_9) | ComputerCount_9
NoL_CheckMap->Check your map to see where my class is.(Vfx_NoL_CheckMap) | NoL_CheckMap
NoL_ClassDismissed->Class dismissed!(Vfx_NoL_ClassDismissed) | NoL_ClassDismissed
NoL_JustinTime->Just in time!(Vfx_NoL_JustinTime) | NoL_JustInTime
NoL_Minutes->minutes.(Vfx_NoL_Minutes) | NoL_Minutes
NoL_MinutesLeft->minutes left.(Vfx_NoL_MinutesLeft) | NoL_MinutesLeft
NoL_Nums_0->0(Vfx_NoL_Nums_0) | NoL_Nums_0
NoL_Nums_1->1(Vfx_NoL_Nums_1) | NoL_Nums_1
NoL_Nums_2->2(Vfx_NoL_Nums_2) | NoL_Nums_2
NoL_Nums_3->3(Vfx_NoL_Nums_3) | NoL_Nums_3
NoL_Nums_4->4(Vfx_NoL_Nums_4) | NoL_Nums_4
NoL_Nums_5->5(Vfx_NoL_Nums_5) | NoL_Nums_5
NoL_Nums_6->6(Vfx_NoL_Nums_6) | NoL_Nums_6
NoL_Nums_7->7(Vfx_NoL_Nums_7) | NoL_Nums_7
NoL_Nums_8->8(Vfx_NoL_Nums_8) | NoL_Nums_8
NoL_Nums_9->9(Vfx_NoL_Nums_9) | NoL_Nums_9
NoL_RemindingYou->Just reminding you to be at my class in(Vfx_NoL_RemindingYou) | NoL_RemindingYou
NoL_Scream->WHYYYYYYY WEREN'T YOU AT MY CLAAAAAAASSS?!?!?!(Vfx_NoL_Scream) | NoL_Scream
NoL_TimesUp->Time's up...(Vfx_NoL_TimesUp) | NoL_TimesUp
NoL_YouThere->You there!(Vfx_NoL_YouThere) | NoL_YouThere
PT_1->1!(Vfx_Playtime_1) | PT_1
PT_10->10!(Vfx_Playtime_10) | PT_10
PT_2->2!(Vfx_Playtime_2) | PT_2
PT_3->3!(Vfx_Playtime_3) | PT_3
PT_4->4!(Vfx_Playtime_4) | PT_4
PT_5->5!(Vfx_Playtime_5) | PT_5
PT_6->6!(Vfx_Playtime_6) | PT_6
PT_7->7!(Vfx_Playtime_7) | PT_7
PT_8->8!(Vfx_Playtime_8) | PT_8
PT_9->9!(Vfx_Playtime_9) | PT_9
PT_Congrats->Wow! That's great! Let's play again... Sometime soon!(Vfx_Playtime_Congrats) | PT_Congrats
PT_Laugh->Hehehehehee!(Vfx_Playtime_Laugh) | PT_Laugh
PT_LetsPlay->Let's play!(Vfx_Playtime_LetsPlay) | PT_LetsPlay
PT_Oops->Oops! You messed up!(Vfx_Playtime_Oops) | PT_Oops
PT_ReadyGo->Ready? Go!(Vfx_Playtime_ReadyGo) | PT_ReadyGo
PT_Sad->Oh! That makes me sad!(Vfx_Playtime_Sad) | PT_Sad
PT_WannaPlay->I wanna play with someone!(Vfx_Playtime_WannaPlay) | PT_WannaPlay
PRI_15->15 seconds(Vfx_PRI_15) | PRI_15
PRI_20->20 seconds(Vfx_PRI_20) | PRI_20
PRI_25->25 seconds(Vfx_PRI_25) | PRI_25
PRI_30->30 seconds(Vfx_PRI_30) | PRI_30
PRI_35->35 seconds(Vfx_PRI_35) | PRI_35
PRI_40->40 seconds(Vfx_PRI_40) | PRI_40
PRI_45->45 seconds(Vfx_PRI_45) | PRI_45
PRI_50->50 seconds(Vfx_PRI_50) | PRI_50
PRI_55->55 seconds(Vfx_PRI_55) | PRI_55
PRI_60->60 seconds(Vfx_PRI_60) | PRI_60
PRI_99->99 seconds(Vfx_PRI_99) | PRI_99
PRI_Coming->Don't worry, I'm coming!(Vfx_PRI_Coming) | PRI_Coming
PRI_Detention->detention for you!(Vfx_PRI_Detention) | PRI_Detention
PRI_NoAfterHours->No being in school after-hours in the halls!(Vfx_PRI_NoAfterHours) | PRI_NoAfterHours
PRI_NoBullying->No bullying in the halls!(Vfx_PRI_NoBullying) | PRI_NoBullying
PRI_NoDrinking->No drinking drinks in the halls!(Vfx_PRI_NoDrinking) | PRI_NoDrinking
PRI_NoEscaping->No escaping detention in the halls!(Vfx_PRI_NoEscaping) | PRI_NoEscaping
PRI_NoFaculty->No entering faculty only rooms in the halls!(Vfx_PRI_NoFaculty) | PRI_NoFaculty
PRI_NoLockers->No looking in other people's lockers in the halls!(Vfx_PRI_NoLockers) | PRI_NoLockers
PRI_NoRunning->No running in the halls!(Vfx_PRI_NoRunning) | PRI_NoRunning
PRI_Scold1->You should know better.(Vfx_PRI_Scold1) | PRI_Scold1
PRI_Scold2->When will you learn?(Vfx_PRI_Scold2) | PRI_Scold2
PRI_Scold3->Your parents will hear about this one!(Vfx_PRI_Scold3) | PRI_Scold3
PRI_Scold4->Don't make me do this again!(Vfx_PRI_Scold4) | PRI_Scold4
PRI_Whistle->*Whistling*(Vfx_PRI_Whistle) | PRI_Whistle
Splash->Sfx_Splash(Sfx_Splash) | Splash
Underwater->(Nothing) | Underwater
Water_Loop->(Nothing) | FloodLoop
Whirlpool->*Whirlpool gurgling*(Sfx_Whirlpool) | Whirlpool
mus_EventNotification_Low->Mfx_mus_EventNotification_Low(Mfx_mus_EventNotification_Low) | mus_EventNotification_Low
