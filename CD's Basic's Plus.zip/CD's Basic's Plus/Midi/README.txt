No midi dumping is currently available.
Below is a list of all valid midi names.
CampMinigame_1_1
DanceV0_5
Elevator
Level_1_End
school
TimeOut_MMP_Corrected
titleFixed
